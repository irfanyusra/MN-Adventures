/**
*The "Id" class.
*Instructor: Mr. Sayed
*Assignment Name: Game - Final Project 
*Class: ICS 4U0-B
*@Author Yusra Irfan 
*@Version 1 
*Date of Submission: 16th June 2016
 */
package mainPackage;

public enum Id {
player , wall,mashroom, enemy, powerUpM, powerUpC,pipe, coin, attack, levelEnd, outOfBounds, changePlayer, bossEnemy, enemyAttack, pipeU;

}
